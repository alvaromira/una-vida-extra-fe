<template>
  <div>
    <h1>This is the Not Found page</h1>
  </div>
</template>

<script>
export default {
  name: "notFound",
};
</script>
