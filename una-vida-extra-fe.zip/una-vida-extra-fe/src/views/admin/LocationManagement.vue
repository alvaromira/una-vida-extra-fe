<template>
  <div>Locations</div>
</template>
