<template>
  <div>
    <h2>This is the sponsors page</h2>
    <p>
      Eu sociis mattis lacinia aliquam vel eu nullam nibh praesent. Litora
      feugiat arcu varius blandit tortor hac commodo magna dictumst! Vulputate
      mus porttitor dui auctor magnis odio convallis class dolor consectetur. Id
      vehicula fusce habitant tortor mauris penatibus. Ornare blandit aliquet
      faucibus risus, arcu venenatis vehicula imperdiet. Sociosqu mollis rhoncus
      habitasse. Platea commodo imperdiet aenean egestas. Placerat porta
      interdum ac nec porttitor hac. A dui eleifend torquent semper ut
      parturient eu. Commodo quis maecenas, eros fames eleifend vehicula.
      Torquent nisl sodales nam libero nulla sodales, dictumst est nec nisl
      taciti a. Ultricies ultricies.
    </p>
    <p>
      Metus id et ultricies. Dictumst dignissim venenatis fringilla quam
      curabitur molestie penatibus fames dolor vitae dictumst vivamus? Augue
      donec auctor volutpat cras vivamus lobortis mi, vel volutpat. Primis
      blandit consequat sed sodales laoreet in consequat. Luctus varius nulla
      nibh duis. Elit taciti leo, est tempor. Cubilia sociosqu arcu sapien
      nascetur lacinia. Dignissim ante placerat praesent nec? Maecenas dui
      nascetur nascetur penatibus taciti viverra pharetra elit sed. Suspendisse
      convallis varius etiam mi sed cursus amet suspendisse, adipiscing dui.
      Accumsan mollis mattis parturient ligula? Condimentum, purus fames euismod
      magna potenti massa molestie. Aliquam ac penatibus vel sociosqu augue
      aliquet posuere pulvinar.
    </p>
    <p>
      Convallis nullam blandit hendrerit tempor sollicitudin aenean netus! Eget
      magnis tempor metus leo. Ad ad phasellus dictumst vulputate taciti
      pretium. Integer tempus fames suscipit aenean diam orci arcu dolor
      interdum. Iaculis nostra lacinia nec mollis eleifend eleifend. Senectus
      vulputate praesent lorem imperdiet fermentum scelerisque proin curabitur
      mus ullamcorper torquent. Ornare orci integer tortor vestibulum nisi,
      varius mi aliquam suspendisse? Massa.
    </p>
    <p>
      Taciti id posuere euismod per, non gravida duis scelerisque? Fermentum
      vestibulum ultricies, phasellus massa nulla. Auctor duis leo, habitasse
      quam vel mi arcu non id. Massa nibh turpis consequat habitasse lobortis
      cras in. Commodo adipiscing libero litora congue sem amet condimentum
      faucibus egestas taciti. Dis fames placerat cras primis dignissim in ipsum
      nisl nascetur? Magnis orci donec elit volutpat justo lectus. Suspendisse
      integer eget nisi sociosqu natoque a class mi. Ligula bibendum lobortis
      cras tempus accumsan. Adipiscing bibendum gravida lacinia litora hac
      feugiat. Laoreet velit praesent posuere sapien non malesuada tellus justo
      sagittis. Primis habitasse proin.
    </p>
    <p>
      Arcu, non magnis felis tempus pharetra luctus in sem pharetra nullam
      maecenas. Sapien potenti fusce euismod. Cras quisque aliquet, nulla
      aliquet facilisis orci. Potenti suspendisse at imperdiet penatibus laoreet
      erat turpis quam habitasse. Duis habitant molestie neque ornare at
      posuere. Id habitant lacinia fames quis bibendum tellus. Dis, primis
      pellentesque ridiculus urna. Congue risus aliquam primis vehicula aptent
      id interdum lacus! Nulla!
    </p>
  </div>
</template>
<script setup></script>
<style scoped></style>
