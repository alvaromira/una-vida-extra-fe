<script setup>
import ProductForm from "../../components/ui/product/ProductForm.vue";
</script>
<template>
  <product-form></product-form>
</template>
