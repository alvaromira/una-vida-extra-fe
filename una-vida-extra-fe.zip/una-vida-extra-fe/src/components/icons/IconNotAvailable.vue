<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="50"
    height="50"
    fill="red"
    view-box="0 0 50 50"
  >
    <circle cx="25" cy="25" r="10" fill="#ff4c4c" />
  </svg>
</template>
