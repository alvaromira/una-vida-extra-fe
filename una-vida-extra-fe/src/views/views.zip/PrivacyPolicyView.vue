<!--Pagina estatica con informacion sobre la politica de privacidad-->
<template>
  <h2>Política de Privacidad</h2>
  <div>
    <p>
      Una Vida Extra&nbsp;te informa sobre su Pol&iacute;tica de Privacidad
      respecto del tratamiento y protecci&oacute;n de los datos de
      car&aacute;cter personal de los usuarios y clientes que puedan ser
      recabados por la navegaci&oacute;n o contrataci&oacute;n de servicios a
      trav&eacute;s del sitio Web&nbsp;https://una-vida-extra.site.
    </p>
    <p>
      En este sentido, el Titular garantiza el cumplimiento de la normativa
      vigente en materia de protecci&oacute;n de datos personales, reflejada en
      la Ley Org&aacute;nica 3/2018, de 5 de diciembre, de Protecci&oacute;n de
      Datos Personales y de Garant&iacute;a de Derechos Digitales (LOPD GDD).
      Cumple tambi&eacute;n con el Reglamento (UE) 2016/679 del Parlamento
      Europeo y del Consejo de 27 de abril de 2016 relativo a la
      protecci&oacute;n de las personas f&iacute;sicas (RGPD).
    </p>
    <p>
      El uso de sitio Web implica la aceptaci&oacute;n de esta Pol&iacute;tica
      de Privacidad as&iacute; como las condiciones incluidas en el Aviso Legal.
    </p>
    <p>Identidad del responsable</p>
    <ul>
      <li>Titular:&nbsp;Una vida extra</li>
      <li>Correo electr&oacute;nico:&nbsp;admin@una-vida-extra.site</li>
      <li>Sitio Web:&nbsp;https://una-vida-extra.site</li>
    </ul>
    <p>Principios aplicados en el tratamiento de datos</p>
    <p>
      En el tratamiento de tus datos personales, el Titular aplicar&aacute; los
      siguientes principios que se ajustan a las exigencias del nuevo reglamento
      europeo de protecci&oacute;n de datos:
    </p>
    <ul>
      <li>
        <strong>Principio de licitud, lealtad y transparencia:</strong>&nbsp;El
        Titular siempre requerir&aacute; el consentimiento para el tratamiento
        de tus datos personales que puede ser para uno o varios fines
        espec&iacute;ficos sobre los que te informar&aacute; previamente con
        absoluta transparencia.
      </li>
      <li>
        <strong>Principio de minimizaci&oacute;n de datos:</strong>&nbsp;El
        Titular te solicitar&aacute; solo los datos estrictamente necesarios
        para el fin o los fines que los solicita.
      </li>
      <li>
        <strong
          >Principio de limitaci&oacute;n del plazo de
          conservaci&oacute;n:</strong
        >&nbsp;Los datos se mantendr&aacute;n durante el tiempo estrictamente
        necesario para el fin o los fines del tratamiento.<br />
        El Titular te informar&aacute; del plazo de conservaci&oacute;n
        correspondiente seg&uacute;n la finalidad. En el caso de suscripciones,
        el Titular revisar&aacute; peri&oacute;dicamente las listas y
        eliminar&aacute; aquellos registros inactivos durante un tiempo
        considerable.
      </li>
      <li>
        <strong>Principio de integridad y confidencialidad:</strong>&nbsp;Tus
        datos ser&aacute;n tratados de tal manera que su seguridad,
        confidencialidad e integridad est&eacute; garantizada. Debes saber que
        el Titular toma las precauciones necesarias para evitar el acceso no
        autorizado o uso indebido de los datos de sus usuarios por parte de
        terceros.
      </li>
    </ul>
    <p>Obtenci&oacute;n de datos personales</p>
    <p>
      Para navegar por&nbsp;https://una-vida-extra.site no es necesario que
      facilites ning&uacute;n dato personal. Los casos en los que s&iacute;
      proporcionas tus datos personales son los siguientes:
    </p>
    <ul>
      <li>
        Al contactar a trav&eacute;s de los formularios de contacto o enviar un
        correo electr&oacute;nico.
      </li>
      <li>Al inscribirte en un formulario de registro</li>
    </ul>
    <p>Tus derechos</p>
    <p>
      El Titular te informa que sobre tus datos personales tienes derecho a:
    </p>
    <ul>
      <li>Solicitar el acceso a los datos almacenados.</li>
      <li>Solicitar una rectificaci&oacute;n o la cancelaci&oacute;n.</li>
      <li>Solicitar la limitaci&oacute;n de su tratamiento.</li>
      <li>Oponerte al tratamiento.</li>
      <li>Solicitar la portabilidad de tus datos.</li>
    </ul>
    <p>
      El ejercicio de estos derechos es personal y por tanto debe ser ejercido
      directamente por el interesado, solicit&aacute;ndolo directamente al
      Titular, lo que significa que cualquier cliente, suscriptor o colaborador
      que haya facilitado sus datos en alg&uacute;n momento puede dirigirse al
      Titular y pedir informaci&oacute;n sobre los datos que tiene almacenados y
      c&oacute;mo los ha obtenido, solicitar la rectificaci&oacute;n de los
      mismos, solicitar la portabilidad de sus datos personales, oponerse al
      tratamiento, limitar su uso o solicitar la cancelaci&oacute;n de esos
      datos en los ficheros del Titular.
    </p>
    <p>
      Para ejercitar tus derechos de acceso, rectificaci&oacute;n,
      cancelaci&oacute;n, portabilidad y oposici&oacute;n tienes que enviar un
      correo electr&oacute;nico a&nbsp;admin@una-vida-extra.site junto con la
      prueba v&aacute;lida en derecho como una fotocopia del D.N.I. o
      equivalente.
    </p>
    <p>
      Tienes derecho a la tutela judicial efectiva y a presentar una
      reclamaci&oacute;n ante la autoridad de control, en este caso, la Agencia
      Espa&ntilde;ola de Protecci&oacute;n de Datos, si consideras que el
      tratamiento de datos personales que te conciernen infringe el Reglamento.
    </p>
    <p>Finalidad del tratamiento de datos personales</p>
    <p>
      Cuando te conectas al sitio Web para mandar un correo al Titular,
      est&aacute;s facilitando informaci&oacute;n de car&aacute;cter personal de
      la que el responsable es el Titular. Esta informaci&oacute;n puede incluir
      datos de car&aacute;cter personal como pueden ser tu direcci&oacute;n IP,
      nombre y apellidos, direcci&oacute;n f&iacute;sica, direcci&oacute;n de
      correo electr&oacute;nico, n&uacute;mero de tel&eacute;fono, y otra
      informaci&oacute;n. Al facilitar esta informaci&oacute;n, das tu
      consentimiento para que tu informaci&oacute;n sea recopilada, utilizada,
      gestionada y almacenada por Una vida extra , s&oacute;lo como se describe
      en la presente Pol&iacute;tica de Privacidad.
    </p>
    <p>
      Los datos personales y la finalidad del tratamiento por parte del Titular
      es diferente seg&uacute;n el sistema de captura de informaci&oacute;n:
    </p>
    <ul>
      <li>
        <strong>Formulario de registro:</strong>&nbsp;El Titular solicita los
        siguientes datos personales: Nombre y apellidos, direcci&oacute;n de
        correo electr&oacute;nico, n&uacute;mero de tel&eacute;fono y
        direcci&oacute;n de tu sitio web para gestionar la lista de
        suscripciones, enviar boletines, promociones y ofertas especiales.<br />
        Los datos que facilites al Titular estar&aacute;n ubicados en los
        servidores de Hostinger Espa&ntilde;a, donde se aloja la web de Una Vida
        Extra.
      </li>
    </ul>
    <p>
      Existen otras finalidades por las que el Titular trata tus datos
      personales:
    </p>
    <ul>
      <li>
        Para garantizar el cumplimiento de las condiciones recogidas en el Aviso
        Legal y en la ley aplicable. Esto puede incluir el desarrollo de
        herramientas y algoritmos que ayuden a este sitio Web a garantizar la
        confidencialidad de los datos personales que recoge.
      </li>
      <li>Para apoyar y mejorar los servicios que ofrece este sitio Web.</li>
      <li>
        Para analizar la navegaci&oacute;n. El Titular recoge otros datos no
        identificativos que se obtienen mediante el uso de cookies que se
        descargan en tu ordenador cuando navegas por el sitio Web cuyas
        caracter&iacute;sticas y finalidad est&aacute;n detalladas en la
        Pol&iacute;tica de Cookies .
      </li>
    </ul>
    <p>Seguridad de los datos personales</p>
    <p>
      Para proteger tus datos personales, el Titular toma todas las precauciones
      razonables y sigue las mejores pr&aacute;cticas de la industria para
      evitar su p&eacute;rdida, mal uso, acceso indebido, divulgaci&oacute;n,
      alteraci&oacute;n o destrucci&oacute;n de los mismos.
    </p>
    <p>
      El sitio Web est&aacute; alojado en&nbsp;Hostinger Espa&ntilde;a. La
      seguridad de tus datos est&aacute; garantizada, ya que toman todas las
      medidas de seguridad necesarias para ello. Puedes consultar su
      pol&iacute;tica de privacidad para tener m&aacute;s informaci&oacute;n.
    </p>
    <p>Contenido de otros sitios web</p>
    <p>
      Las p&aacute;ginas de este sitio Web pueden incluir contenido incrustado
      (por ejemplo, v&iacute;deos, im&aacute;genes, art&iacute;culos, etc.). El
      contenido incrustado de otras web se comporta exactamente de la misma
      manera que si hubieras visitado la otra web.
    </p>
    <p>
      Estos sitios Web pueden recopilar datos sobre ti, utilizar cookies,
      incrustar un c&oacute;digo de seguimiento adicional de terceros, y
      supervisar tu interacci&oacute;n usando este c&oacute;digo.
    </p>
    <p>Pol&iacute;tica de Cookies</p>
    <p>
      Para que este sitio Web funcione correctamente necesita utilizar cookies,
      que es una informaci&oacute;n que se almacena en tu navegador web.
    </p>
    <p>
      En la p&aacute;gina Pol&iacute;tica de Cookies puedes consultar toda la
      informaci&oacute;n relativa a la pol&iacute;tica de recogida, la finalidad
      y el tratamiento de las cookies.
    </p>
    <p>Legitimaci&oacute;n para el tratamiento de datos</p>
    <p>La base legal para el tratamiento de tus datos es: el consentimiento.</p>
    <p>
      Para contactar con el Titular, suscribirte a un bolet&iacute;n o realizar
      comentarios en este sitio Web tienes que aceptar la presente
      Pol&iacute;tica de Privacidad.
    </p>
    <p>Categor&iacute;as de datos personales</p>
    <p>Las categor&iacute;as de datos personales que trata el Titular son:</p>
    <ul>
      <li>Datos identificativos.</li>
    </ul>
    <p>Conservaci&oacute;n de datos personales</p>
    <p>
      Los datos personales que proporciones al Titular se conservar&aacute;n
      hasta que solicites su supresi&oacute;n.
    </p>
    <p>Destinatarios de datos personales</p>
    <p>Actualmente no hay destinatarios de datos personales.</p>
    <p>
      Se mencionan a continuaci&oacute;n los que pueden incluirse o usarse en el
      futuro pr&oacute;ximo:
    </p>
    <ul>
      <li>
        <strong>Google Analytics</strong>&nbsp;es un servicio de
        anal&iacute;tica web prestado por Google, Inc., una
        compa&ntilde;&iacute;a de Delaware cuya oficina principal est&aacute; en
        1600 Amphitheatre Parkway, Mountain View (California), CA 94043, Estados
        Unidos (&ldquo;Google&rdquo;). Encontrar&aacute;s m&aacute;s
        informaci&oacute;n en:&nbsp;<strong
          ><a href="https://analytics.google.com/"
            >https://analytics.google.com</a
          ></strong
        ><br />
        Google Analytics utiliza &ldquo;cookies&rdquo;, que son archivos de
        texto ubicados en tu ordenador, para ayudar al Titular a analizar el uso
        que hacen los usuarios del sitio Web. La informaci&oacute;n que genera
        la cookie acerca del uso del sitio Web (incluyendo tu direcci&oacute;n
        IP) ser&aacute; directamente transmitida y archivada por Google en los
        servidores de Estados Unidos.
      </li>
      <li>
        <strong>DoubleClick by Google</strong>&nbsp;es un conjunto de servicios
        publicitarios proporcionado por Google, Inc., una compa&ntilde;&iacute;a
        de Delaware cuya oficina principal est&aacute; en 1600 Amphitheatre
        Parkway, Mountain View (California), CA 94043, Estados Unidos
        (&ldquo;Google&rdquo;).<br />
        Encontrar&aacute;s m&aacute;s informaci&oacute;n en:&nbsp;<strong
          ><a href="https://www.doubleclickbygoogle.com/"
            >https://www.doubleclickbygoogle.com</a
          ></strong
        ><br />
        DoubleClick utiliza &ldquo;cookies&rdquo;, que son archivos de texto
        ubicados en tu ordenador y que sirven para aumentar la relevancia de los
        anuncios relacionados con tus b&uacute;squedas recientes. En la
        Pol&iacute;tica de privacidad de Google se explica c&oacute;mo Google
        gestiona tu privacidad en lo que respecta al uso de las cookies y otra
        informaci&oacute;n.
      </li>
    </ul>
    <p>
      Tambi&eacute;n puedes ver una lista de los tipos de cookies que utiliza
      Google y sus colaboradores y toda la informaci&oacute;n relativa al uso
      que hacen de cookies publicitarias.
    </p>
    <p>Navegaci&oacute;n Web</p>
    <p>
      Al navegar por&nbsp;una-vida-extra.site se pueden recoger datos no
      identificativos, que pueden incluir, la direcci&oacute;n IP,
      geolocalizaci&oacute;n, un registro de c&oacute;mo se utilizan los
      servicios y sitios, h&aacute;bitos de navegaci&oacute;n y otros datos que
      no pueden ser utilizados para identificarte.
    </p>
    <p>
      Actualmente, el sitio Web no utiliza los siguientes servicios de
      an&aacute;lisis de terceros. No obstante, se prev&eacute; la
      utilizaci&oacute;n de
    </p>
    <ul>
      <li>Google Analytics</li>
      <li>DoubleClick por Google</li>
    </ul>
    <p>
      El Titular utiliza la informaci&oacute;n obtenida para obtener datos
      estad&iacute;sticos, analizar tendencias, administrar el sitio, estudiar
      patrones de navegaci&oacute;n y para recopilar informaci&oacute;n
      demogr&aacute;fica.
    </p>
    <p>Exactitud y veracidad de los datos personales</p>
    <p>
      Te comprometes a que los datos facilitados al Titular sean correctos,
      completos, exactos y vigentes, as&iacute; como a mantenerlos debidamente
      actualizados.
    </p>
    <p>
      Como Usuario del sitio Web eres el &uacute;nico responsable de la
      veracidad y correcci&oacute;n de los datos que remitas al sitio exonerando
      a el Titular de cualquier responsabilidad al respecto.
    </p>
    <p>Aceptaci&oacute;n y consentimiento</p>
    <p>
      Como Usuario del sitio Web declaras haber sido informado de las
      condiciones sobre protecci&oacute;n de datos de car&aacute;cter personal,
      aceptas y consientes el tratamiento de los mismos por parte del Titular en
      la forma y para las finalidades indicadas en esta Pol&iacute;tica de
      Privacidad.
    </p>
    <p>Revocabilidad</p>
    <p>
      Para ejercitar tus derechos de acceso, rectificaci&oacute;n,
      cancelaci&oacute;n, portabilidad y oposici&oacute;n tienes que enviar un
      correo electr&oacute;nico a&nbsp;admin@una-vida-extra.site junto con la
      prueba v&aacute;lida en derecho como una fotocopia del D.N.I. o
      equivalente.
    </p>
    <p>
      El ejercicio de tus derechos no incluye ning&uacute;n dato que el Titular
      est&eacute; obligado a conservar con fines administrativos, legales o de
      seguridad.
    </p>
    <p>Cambios en la Pol&iacute;tica de Privacidad</p>
    <p>
      El Titular se reserva el derecho a modificar la presente Pol&iacute;tica
      de Privacidad para adaptarla a novedades legislativas o jurisprudenciales,
      as&iacute; como a pr&aacute;cticas de la industria.
    </p>
    <p>
      Estas pol&iacute;ticas estar&aacute;n vigentes hasta que sean modificadas
      por otras debidamente publicadas.
    </p>
  </div>
</template>
<style scoped>
h2 {
  padding-bottom: 2rem;
}
</style>
