<!--Vista donde se muestra un mensaje de pagina no encontrada-->
<template>
  <div>
    <h1>Vaya... ves esto porque no encontramos lo que buscas :(.</h1>
  </div>
</template>
<script setup></script>
